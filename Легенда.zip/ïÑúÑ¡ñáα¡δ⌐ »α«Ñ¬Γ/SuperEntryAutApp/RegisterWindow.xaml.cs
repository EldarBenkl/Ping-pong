using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Newtonsoft.Json;


namespace SuperEntryAutApp
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        
        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string username = LoginTextBox.Text.Trim();
            string password = PasswordBox.Password.Trim();
            string confirmPassword = ConfirmPasswordBox.Password.Trim();
            string email = EmailTextBox.Text.Trim();
            string role = (RoleComboBox.SelectedItem as ComboBoxItem).Content.ToString().ToLower();

            // Проверка на пустые поля
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Все поля должны быть заполнены.");
                return;
            }

            // Проверка на совпадение паролей
            if (password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают.");
                return;
            }

            // Попытка зарегистрировать нового пользователя
            bool success = UserData.Register(username, password, email, role);

            if (success == true)
            {              
                MessageBox.Show("Регистрация прошла успешно! Теперь вы можете войти.");
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                Close();
                
                
            }
            else
            {
                MessageBox.Show("Пользователь с таким логином или email уже существует.");
            }
        }
    }   
}
