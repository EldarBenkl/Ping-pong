using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using System.Windows; 
namespace SuperEntryAutApp
{
    internal class UserData
    {
        private static readonly string dataFile = "users.xml";
        public static List<User> Users = new List<User>();

        public static void LoadData()
        {
            if (File.Exists(dataFile))
            {
                XDocument doc = XDocument.Load(dataFile);
                Users = doc.Descendants("User")
                    .Select(u => new User(
                        u.Element("Username")?.Value,
                        u.Element("Password")?.Value,
                        u.Element("Email")?.Value,
                        u.Element("Role")?.Value))
                    .ToList();
            }
        }

        public static User LoginByUsername(string username, string password)
        {
            return Users.FirstOrDefault(u => u.Username == username && u.Password == password);
        }

        public static User LoginByEmail(string email, string password)
        {
            return Users.FirstOrDefault(u => u.Email == email && u.Password == password);
        }

        public static void SaveData()
        {
            XDocument doc;

            // Проверяем, существует ли файл
            if (File.Exists(dataFile))
            {
                // Загружаем существующий XML файл
                doc = XDocument.Load(dataFile);
            }
            else
            {
                // Создаем новый XML документ, если файла не существует
                doc = new XDocument(new XElement("Users"));
            }

            // Добавляем новых пользователей в XML
            foreach (var user in Users)
            {
                // Проверяем, есть ли уже пользователь в XML, чтобы избежать дублирования
                var existingUser = doc.Root.Elements("User").FirstOrDefault(u => u.Element("Username").Value == user.Username || u.Element("Email").Value == user.Email);

                if (existingUser == null)  // Если пользователь не найден, добавляем его
                {
                    doc.Root.Add(
                        new XElement("User",
                            new XElement("Username", user.Username),
                            new XElement("Password", user.Password),
                            new XElement("Email", user.Email),
                            new XElement("Role", user.Role)
                        )
                    );
                }
            }

            // Сохраняем обновлённый документ
            doc.Save(dataFile);
        }

        public static bool Register(string username, string password, string email, string role)
        {
            LoadData();

            if (Users.Any(u => u.Username == username || u.Email == email))
            {
                return false; // Если пользователь уже существует, возвращаем false
            }

            User newUser = new User(username, password, email, role);
            Users.Add(newUser);

            SaveData();

            return true; // Успешная регистрация
        }
    }
}
