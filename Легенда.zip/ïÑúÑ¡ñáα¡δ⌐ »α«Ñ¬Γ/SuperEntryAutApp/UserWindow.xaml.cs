using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO;
namespace SuperEntryAutApp
{
    /// <summary>
    /// Логика взаимодействия для UserWindow.xaml
    /// </summary>
    public partial class UserWindow : Window
    {

        // Переменные для управления движением
        private double ballSpeedX = 5;
        private double ballSpeedY = 5;
        private double leftPaddleSpeed = 0;
        private double rightPaddleSpeed = 0;

        private int leftScore = 0;
        private int rightScore = 0;

        private DispatcherTimer gameTimer = new DispatcherTimer();
        public UserWindow()
        {
            InitializeComponent();
            
            // Таймер для обновления состояния игры
            gameTimer.Interval = TimeSpan.FromMilliseconds(20);
            gameTimer.Tick += GameTick;
            gameTimer.Start();

            // Управление клавишами
            KeyDown += new KeyEventHandler(OnKeyDown);
            KeyUp += new KeyEventHandler(OnKeyUp);
        }

        private void GameTick(object sender, EventArgs e)
        {
            // Движение мяча
            Canvas.SetLeft(Ball, Canvas.GetLeft(Ball) + ballSpeedX);
            Canvas.SetTop(Ball, Canvas.GetTop(Ball) + ballSpeedY);

            // Проверка на столкновение с верхней и нижней границей
            if (Canvas.GetTop(Ball) <= 0 || Canvas.GetTop(Ball) + Ball.Height >= GameCanvas.ActualHeight)
            {
                ballSpeedY = -ballSpeedY;
            }

            // Проверка на выход мяча за пределы поля (счет)
            if (Canvas.GetLeft(Ball) <= 0)
            {
                rightScore++;
                ResetBall();
            }
            else if (Canvas.GetLeft(Ball) + Ball.Width >= GameCanvas.ActualWidth)
            {
                leftScore++;
                ResetBall();
            }

            // Движение ракеток
            Canvas.SetTop(LeftPaddle, Canvas.GetTop(LeftPaddle) + leftPaddleSpeed);
            Canvas.SetTop(RightPaddle, Canvas.GetTop(RightPaddle) + rightPaddleSpeed);

            // Ограничение движения ракеток
            if (Canvas.GetTop(LeftPaddle) < 0)
                Canvas.SetTop(LeftPaddle, 0);
            if (Canvas.GetTop(LeftPaddle) + LeftPaddle.Height > GameCanvas.ActualHeight)
                Canvas.SetTop(LeftPaddle, GameCanvas.ActualHeight - LeftPaddle.Height);

            if (Canvas.GetTop(RightPaddle) < 0)
                Canvas.SetTop(RightPaddle, 0);
            if (Canvas.GetTop(RightPaddle) + RightPaddle.Height > GameCanvas.ActualHeight)
                Canvas.SetTop(RightPaddle, GameCanvas.ActualHeight - RightPaddle.Height);

            Colision();

            if (rightScore + leftScore == 21)
            {
                if (rightScore > leftScore)
                {
                    MessageBox.Show("Правая ракетка победила");
                    gameTimer.Stop();
                }
                else
                {
                    MessageBox.Show("Левая ракетка победила");
                    gameTimer.Stop();
                }
            }
        }

        private void Colision()
        {

            // Проверка столкновения мяча с ракетками
            if (Canvas.GetLeft(Ball) <= Canvas.GetLeft(LeftPaddle) + LeftPaddle.Width &&
                Canvas.GetTop(Ball) + Ball.Height >= Canvas.GetTop(LeftPaddle) &&
                Canvas.GetTop(Ball) <= Canvas.GetTop(LeftPaddle) + LeftPaddle.Height)             
            {
                ballSpeedX = -ballSpeedX;

                ballSpeedX *= 1.0625;
                ballSpeedY *= 1.0625;
            }
            if (Canvas.GetLeft(Ball) + Ball.Width >= Canvas.GetLeft(RightPaddle) && // Правая сторона мяча касается левой стороны ракетки
    Canvas.GetTop(Ball) + Ball.Height >= Canvas.GetTop(RightPaddle) && // Нижняя сторона мяча ниже верхней ракетки
    Canvas.GetTop(Ball) <= Canvas.GetTop(RightPaddle) + RightPaddle.Height) // Верхняя сторона мяча выше нижней ракетки
            {
                ballSpeedX = -ballSpeedX;
                ballSpeedX *= 1.0625;
                ballSpeedY *= 1.0625;
            }

            // Обновление счета
            Score.Text = $"{leftScore} : {rightScore}";
           
        }

        private void OnKeyDown(object sender, KeyEventArgs e)
        {
            // Управление левой ракеткой
            if (e.Key == Key.W)
            {
                leftPaddleSpeed = -10;
            }
            if (e.Key == Key.S)
            {
                leftPaddleSpeed = 10;
            }

            // Управление правой ракеткой
            if (e.Key == Key.Up)
            {
                rightPaddleSpeed = -10;
            }
            if (e.Key == Key.Down)
            {
                rightPaddleSpeed = 10;
            }
        }

        private void OnKeyUp(object sender, KeyEventArgs e)
        {
            // Остановка движения ракеток при отпускании клавиш
            if (e.Key == Key.W || e.Key == Key.S)
            {
                leftPaddleSpeed = 0;
            }
            if (e.Key == Key.Up || e.Key == Key.Down)
            {
                rightPaddleSpeed = 0;
            }
        }

        private void ResetBall()
        {
            // Возвращаем мяч в центр поля и изменяем направление движения
            Canvas.SetLeft(Ball, GameCanvas.ActualWidth / 2 - Ball.Width / 2);
            Canvas.SetTop(Ball, GameCanvas.ActualHeight / 2 - Ball.Height / 2);
            ballSpeedX = -ballSpeedX;
        }

        private void LoadImages()
        {
            if (File.Exists("images.txt"))
            {
                // Читаем все строки из файла
                string[] lines = File.ReadAllLines("images.txt");

                string paddleImagePath = null;
                string ballImagePath = null;

                // Проходим по строкам и находим нужные нам пути
                foreach (string line in lines)
                {
                    if (line.StartsWith("paddleImage:"))
                    {
                        paddleImagePath = line.Substring("paddleImage:".Length).Trim();
                    }
                    else if (line.StartsWith("ballImage:"))
                    {
                        ballImagePath = line.Substring("ballImage:".Length).Trim();
                    }
                }

                // Проверяем и загружаем изображение для paddle
                if (!string.IsNullOrEmpty(paddleImagePath) && File.Exists(paddleImagePath))
                {
                    ImageBrush paddleBrush = new ImageBrush();
                    paddleBrush.ImageSource = new BitmapImage(new Uri(paddleImagePath));
                    LeftPaddle.Fill = paddleBrush;
                    RightPaddle.Fill = paddleBrush;
                }

                // Проверяем и загружаем изображение для ball
                if (!string.IsNullOrEmpty(ballImagePath) && File.Exists(ballImagePath))
                {
                    ImageBrush ballBrush = new ImageBrush();
                    ballBrush.ImageSource = new BitmapImage(new Uri(ballImagePath));
                    Ball.Fill = ballBrush;  // Например, это эллипс для ball
                }
            }
        }


        private void LoadColorFromFile()
        {
            if (File.Exists("color.txt"))
            {
                // Читаем данные цвета из файла
                string colorString = File.ReadAllText("color.txt");
                var colorParts = colorString.Split(',');

                if (colorParts.Length == 4)
                {
                    // Преобразуем строку в цвет (ARGB)
                    byte a = byte.Parse(colorParts[0]);
                    byte r = byte.Parse(colorParts[1]);
                    byte g = byte.Parse(colorParts[2]);
                    byte b = byte.Parse(colorParts[3]);

                    var loadedColor = System.Windows.Media.Color.FromArgb(a, r, g, b);

                    // Применяем цвет к фону
                    GameCanvas.Background = new SolidColorBrush(loadedColor);
                }
            }
        }

        private void Load(object sender, RoutedEventArgs e)
        {
            LoadImages();
            LoadColorFromFile();
        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            gameTimer.Stop();
            Close();
        }

        private void Pause_click(object sender, RoutedEventArgs e)
        {
            gameTimer.Stop();
            PlayButton.Visibility = Visibility.Visible;
        }
        
        private void Play_Click(object sender, RoutedEventArgs e)
        {
            gameTimer.Start();
            PlayButton.Visibility = Visibility.Collapsed;
        }

        
    } 
}

