using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Drawing;
using System.Windows.Forms;

namespace SuperEntryAutApp
{
    /// <summary>
    /// Логика взаимодействия для AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
        }

        private void ChangeBackground_Click(object sender, RoutedEventArgs e)
        {
            var colorDialog = new System.Windows.Forms.ColorDialog();

            if (colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                // Преобразуем выбранный цвет из System.Windows.Forms в WPF Color
                var selectedColor = System.Windows.Media.Color.FromArgb(
                    colorDialog.Color.A,
                    colorDialog.Color.R,
                    colorDialog.Color.G,
                    colorDialog.Color.B
                );

                // Применяем цвет к фону GameCanvas
                GameCanvas.Background = new SolidColorBrush(selectedColor);

                // Сохраняем цвет в текстовый файл (ARGB формат)
                SaveColorToFile(selectedColor);
            }
        }

        private void ChangeBallImage_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new Microsoft.Win32.OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.png;*.jpg;*.jpeg";

            if (openFileDialog.ShowDialog() == true)
            {
                var imageBrush = new ImageBrush();
                imageBrush.ImageSource = new BitmapImage(new Uri(openFileDialog.FileName));
                Ball.Fill = imageBrush;

                // Сохраняем путь к изображению мяча в файл
                SaveImagePath("ballImage", openFileDialog.FileName);
            }
        }      
        private void ChangePaddleImage_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new Microsoft.Win32.OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.png;*.jpg;*.jpeg";

            if (openFileDialog.ShowDialog() == true)
            {
                var paddleImage = new ImageBrush();
                paddleImage.ImageSource = new BitmapImage(new Uri(openFileDialog.FileName));
                PaddleLeft.Fill = paddleImage;
                PaddleRight.Fill = paddleImage;

                // Сохраняем путь к изображению ракеток в файл
                SaveImagePath("paddleImage", openFileDialog.FileName);
            }
        }
        private void OpenUserWindow_Click(object sender, RoutedEventArgs e)
        {
            UserWindow userWindow = new UserWindow(); // Предполагается, что есть окно UserWindow
            userWindow.Show();
        }
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.MessageBox.Show("Программа выполнена только профи, не повторять в домашних условиях", "О программе", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SaveImagePath(string imageType, string filePath)
        {
            var lines = new List<string>();

            // Если файл существует, считываем его содержимое
            if (File.Exists("images.txt"))
            {
                lines = File.ReadAllLines("images.txt").ToList();
            }

            // Удаляем старую запись для этого типа изображения
            lines.RemoveAll(line => line.StartsWith(imageType + ":"));

            // Добавляем новую запись для этого типа изображения
            lines.Add(imageType + ":" + filePath);

            // Записываем обновлённый список в файл
            File.WriteAllLines("images.txt", lines);

        }

        private void SaveColorToFile(System.Windows.Media.Color color)
        {
            // Записываем ARGB значение цвета в файл
            string colorString = $"{color.A},{color.R},{color.G},{color.B}";
            File.WriteAllText("color.txt", colorString);
        }
    }
}
