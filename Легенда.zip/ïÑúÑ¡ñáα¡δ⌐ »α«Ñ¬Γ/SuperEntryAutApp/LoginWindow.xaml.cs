using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Newtonsoft.Json;

namespace SuperEntryAutApp
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            UserData.LoadData(); 
        }


        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {

            string loginOrEmail = LoginEmailTextBox.Text.Trim();
            string password = PasswordBox.Password.Trim();

            if (string.IsNullOrEmpty(loginOrEmail) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Введите логин/почту и пароль");
                return;
            }

            User user = null;

            if (LoginMethodComboBox.SelectedIndex == 0) 
            {
                user = UserData.LoginByUsername(loginOrEmail, password);
            }
            else 
            {
                user = UserData.LoginByEmail(loginOrEmail, password);
            }

            if (user != null)
            {
                MessageBox.Show($"Здарова, {user.Role} {user.Username}");
                if(user.Role == "администратор")
                {
                    AdminWindow adminWindow = new AdminWindow();
                    adminWindow.Show();
                    Close();
                }
                else
                {
                    UserWindow userWindow = new UserWindow();
                    userWindow.Show();
                    Close();
                }
            }
            else
            {
                MessageBox.Show("Неправильный логин или пароль");
            }
        }

        private void LoginMethodComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (LoginMethodComboBox.SelectedIndex == 1)
            {
                LoginOrEmailTextBlock.Text = "Email:";
            }
           
        }

        private void LoginEmailTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
